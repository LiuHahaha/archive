function lp = logjointprob(Z, X, A, phi, prior)
lp = -42;
