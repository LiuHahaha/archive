function allZ = allpaths(T,K)
allZ = allpaths_recurs([], T, K);

function allZ = allpaths_recurs(path_so_far, T, K)
if numel(path_so_far)==T
  allZ = {path_so_far};
  return
end
allZ = {};
for k=1:K
  newpath = [path_so_far k];
  allZ = concat_cells(allZ, allpaths_recurs(newpath, T, K));
end



