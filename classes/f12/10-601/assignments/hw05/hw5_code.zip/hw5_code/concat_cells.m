function ret = concat_cells(cell1, cell2)
% Take two cells as input. Return a new cell that is their concatenation.
% (does Matlab have this in its standard library?)
ret = {};
for i=1:numel(cell1)
  ret{i} = cell1{i};
end
for i=1:numel(cell2)
  ret{i+numel(cell1)} = cell2{i};
end
