# from params_and_data import A,phi,prior, smallX, bigX

def allpaths(sofar, T, K):
    retpaths = []
    if len(sofar)==T:
        return [sofar]
    for k in range(K):
        newpath = sofar[:] + [k]
        retpaths += allpaths(newpath, T, K)
    return retpaths

def test_stuff():
    print viterbi_bestpath(smallX)
    print exhaustive_bestpath(smallX)

###########

def logjointprob(Z, X, A, phi, prior):
    return -42

def exhaustive_bestpath(X, A, phi, prior):
    global A,phi,prior
    T = len(X);
    K = len(phi[0])
    return [1] * T

def viterbi_bestpath(X, A, phi, prior):
    global A,phi,prior
    T = len(X);
    K = len(phi[0])
    return [1] * T

