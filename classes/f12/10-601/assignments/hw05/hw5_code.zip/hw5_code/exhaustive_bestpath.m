function bestZ = exhaustive_bestpath(X, A, phi, prior)
T = numel(X);
K = size(A,1);

allZ = allpaths(T,K-1);
for i=1:numel(allZ)
  disp(allZ{i});
end

bestZ = ones(1, T);
