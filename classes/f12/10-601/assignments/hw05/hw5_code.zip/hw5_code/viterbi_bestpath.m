function Z = viterbi_bestpath(X, A, phi, prior)
T = numel(X);
K = size(phi,2);
resultZ = ones(1, T);
