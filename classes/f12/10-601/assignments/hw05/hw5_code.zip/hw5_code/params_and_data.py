# These are copied straight from matlab.  See comments there.
# Look out for 0 vs 1 issues.

prior = [0.8, 0.2, 0]
A = [
  [0.8, 0.1, 0.5],
  [0.1, 0.8, 0.5],
  [0.1, 0.1, 0],
]
phi = [
  [0.7, 0.1],
  [0.2, 0.2],
  [0.1, 0.7],
]

smallX=[1,1,3,1,2,3,3];
bigX=[2,3,3,2,3,2,3,2,2,3,1,3,3,1,1,1,2,1,1,1,3,1,2,1,1,1,2,3,3,2,3,2,2];

