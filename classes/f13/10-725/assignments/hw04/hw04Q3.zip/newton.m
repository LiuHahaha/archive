function [U, i] = newton(init_U, y, D, lambda, tau, s_0, gamma_1, gamma_2, e_in)

  [m n] = size(D);

  % we use these terms a lot
  d = @(u) D'*u;
  yd = @(u) y.*d(u);

  % see part (b) of write-up for function, gradient, and hessian derivations
  % objective function pieces (scalars)
  H = @(p) -(p.*log(p) + (1 - p).*log(1 - p));
  g = @(u) sum(H(yd(u)));
  phi = @(u) sum(log(yd(u)) + log(1 - yd(u))) ...
           + sum(log(lambda - u) + log(u + lambda));
  % gradient pieces (n-vectors)
  c = @(u) log((1 - yd(u))./yd(u)).*y;
  a = @(u) 2*u./(u.^2 - lambda^2);
  b = @(u) dot((2*yd(u) - 1),(diag(1./(d(u).*(yd(u) - 1))))*y)*ones(n,1);
  % hessian pieces (diagonal n X n matrices)
  W = @(u) diag(1./(d(u).*(yd(u) - 1)));
  U = @(u) diag(-2*(u.^2 + 1)./((u.^2 - 1).^2));
  V = @(u) diag((-2*(yd(u).^2) + 2*yd(u) - 1)./(((d(u)).^2).*(yd(u) - 1).^2));
  % put the pieces together
  fcn = @(u) tau*g(u) + phi(u);
  grad = @(u) D*(tau*c(u) + b(u)) + a(u);
  hess = @(u) D*(tau*W(u) + V(u))*D' + U(u);

  % don't know how many iterations we'll need, so can't allocate outputs...
  % initialize U
  Us(1,:) = init_U;

  i = 1; % iteration count

  % initialize function value, gradient, and hessian
  fcn_here = fcn(Us(i,:)');
  grad_here = grad(Us(i,:)');
  hess_here = hess(Us(i,:)');

  % approximate strict versions of constaints
  A = vertcat(diag(y)*D',-diag(y)*D');
  b = [0.9*ones(n,1); -0.1*ones(n,1)];
  l_vec = [0.9*lambda*ones(m,1); 0.9*lambda*ones(m,1)];

  while(norm(grad_here) >= e_in)

    %%% BACKTRACKING %%%
    s = s_0;
    step = -s*(inv(hess_here)*grad_here);
    there = Us(i,:)' + step;

    % need to check constraints AND descent
    while(any(A*there > b) || ...
          any([there; -there] > l_vec) || ...
          fcn(there) > fcn_here - gamma_1*s*norm(grad_here))
      s = gamma_2*s;
      step = gamma_2*step;
      there = Us(i,:)' + step;
    end

    % main update step
    Us(i + 1,:) = there';
    i = i + 1

    % update function value, gradient, and hessian
    fcn_here = fcn(Us(i,:)');
    grad_here = grad(Us(i,:)');
    hess_here = hess(Us(i,:)');
  end

%  % calculate fcn_vals at each point in Us
%  for j=1:i
%    fcn_vals(i) = fcn(Us(i,:));
%  end
%
   U = Us(end,:);

end
