function [Xs, i] = barrier(z, D, lambda, tau_0, mu, s_0, gamma_1, gamma_2,...
                                                                  e_in, e_out)

  [m n] = size(D);

  tau = tau_0;
  y = 2*z - 1; % see write-up for transformation

  % solve a quick LP to find a strictly feasible point
  yD = diag(y)*D';
  f = zeros(m,1);
  A = vertcat(yD,-yD);
  b = [0.98*ones(n,1); -0.02*ones(n,1)];
  lambda_vec = 0.99*lambda*ones(m,1);
  Xs(1,:) = linprog(f, A, b, [], [], -lambda_vec, lambda_vec);

  i = 0; % current iteration count

  first = true; % need at least one iteration to check exit condition
  while(first || norm(Xs(i + 1,:) - Xs(i,:)) >= e_out)

    if(not(first)) norm(Xs(i + 1,:) - Xs(i,:)), end

    first = false;
    i = i + 1;

    % run internal Newton's method
    [Xs(i + 1,:) j] = newton(Xs(1,:), y, D, lambda, tau, s_0, gamma_1, gamma_2, e_in);

    tau = tau*mu; % reduce barrier (actually, increase function)
  end

%  % calculate fcn_vals at each point in Xs
%  for j=1:i
%    fcn_vals(i) = subs(fcn, [x y], Xs(i,:));
%  end
%
%  Xs = Xs';

end
