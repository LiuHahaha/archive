clear
set(0, 'defaultaxesfontsize', 20);
rng shuffle;

syms x y

% objective functions
f{1} = 1.125.*x.^2 + 0.5.*x.*y + 0.75.*y.^2 + 2.*x + 2.*y;
f{2} = 0.5.*(x.^2 + y.^2) + 50.*log(1 + exp(-0.5.*y)) + 50.*log(1 + exp(0.2.*x));
f{3} = 0.1.*(x.^2 + y - 11).^2 + 0.1.*(x + y.^2 - 7).^2;
f{4} = 0.002.*(1 - x).^2 + 0.2.*(y - x.^2).^2;

% gradient functions
for i=1:4
  grad_f{i} = gradient(f{i});
end

% hessian functions
for i=1:4
  hess_f{i} = hessian(f{i});
end

init_X = [0; 0]; % start at origin
stop = 10.^(-6); % minimum norm of gradient to continue
step_size = 1; % constant step size 1

for i=1:4

  % Newton's Method
  [X1s, fcn_vals1, i1] = newton(f{i}, grad_f{i}, hess_f{i},...
    init_X, stop, step_size);

  % BFGS with backtracking line search
  [X2s, fcn_vals2, i2] = bfgs(f{i}, grad_f{i}, hess_f{i},...
    init_X, stop, step_size);

  % plot contour and algorithm path
  figure(2i - 1); clf;
  ezcontour(f{i}); hold on;
  plot(X1s(1,:), X1s(2,:),'r.-');
  axis([-6 6 -6 6]);
  figure(2i); clf;
  ezcontour(f{i}); hold on;
  plot(X2s(1,:), X2s(2,:),'.-');
  axis([-6 6 -6 6]);


  % Final points, function values, and number of iterations
  fXs(i,:,:) = [X1s(:,end); X2s(:,end)];
  ffs(i,:) = double([fcn_vals1(end); fcn_vals2(end)]);
  fis(i,:) = double([i1; i2]);
end
