function [Xs, fcn_vals, i] = newton(fcn, grad, hess, init_X, stop, step_size);

  syms x y

  % don't know how many iterations we'll need, so can't allocate outputs...
  % initialize X
  Xs(1,:) = init_X;

  i = 1; % iteration count

  % initialize gradient and hessian
  grad_here = double(subs(grad, [x y], Xs(i,:)));
  hess_here = double(subs(hess, [x y], Xs(i,:)));

  while(norm(grad_here) >= stop)

    % main update step
    Xs(i + 1,:) = Xs(i,:) - (inv(hess_here)*grad_here)';
    i = i + 1;

    % update gradient and hessian
    grad_here = subs(grad, [x y], Xs(i,:));
    hess_here = subs(hess, [x y], Xs(i,:));
  end

  % calculate fcn_vals at each point in Xs
  for j=1:i
    fcn_vals(i) = subs(fcn, [x y], Xs(i,:));
  end

  Xs = Xs';

end
