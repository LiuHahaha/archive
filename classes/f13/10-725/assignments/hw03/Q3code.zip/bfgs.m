function [Xs, fcn_vals, i] = newton(fcn, grad, hess, init_X, stop, step_size);

  % backtracking line search parameters
  alpha = 0.5;
  beta = 0.5;
  max_backtracks = 10;

  % make x and y symbolic
  syms x y

  % don't know how many iterations we'll need, so can't allocate outputs...
  % initialize X
  Xs(:,1) = init_X;

  i = 1; % iteration count

  % initialize function value, gradient, and, inverse hessian
  f_here = double(subs(fcn, [x; y], Xs(:,i)));
  grad_here = double(subs(grad, [x; y], Xs(:,i)));
  H_here = inv(double(subs(hess, [x; y], Xs(:,i))));

  while(norm(grad_here) >= stop)

    d = -H_here*grad_here; % search direction

    t = 1; % initial step size
    f_there = double(subs(fcn, [x; y], Xs(:,i) + t.*d));
    %%%Backtracking Line Search%%%
    num_backtracks = 1;
    while(f_there > f_here + alpha*t*norm(grad_here))
      t = beta*t; % shorter step size
      f_there = double(subs(fcn, [x; y], Xs(:,i) + t.*d));
      num_backtracks = num_backtracks + 1;
      if(num_backtracks > max_backtracks) break; end
    end

    % main update step
    p = t .* d; % update
    Xs(:,i + 1) = Xs(:,i) + p; % next X value
    i = i + 1;
    grad_there = double(subs(grad, [x; y], Xs(:,i)));
    q = grad_there - grad_here; % gradient update

    % update function value and gradient for next iteration
    f_here = f_there;
    grad_here = grad_there;

    % use that god-awful formula to update the inverse Hessian estimate
    T1 = (1 + (dot(q,H_here*q)./dot(p,q)))*(p*(p'));
    T2 = (p*(q')*H_here + H_here*q*(p'));
    H_here = H_here + (T1 - T2)./(dot(p,q));
  end

  % calculate fcn_vals at each point in Xs
  for j=1:i
    fcn_vals(i) = double(subs(fcn, [x; y], Xs(:,i)));
  end
end
