function [Xs, fcn_vals] = gd_backtrack(fcn, grad, init_X, n_steps, stepsize,...
						alpha, beta, max_backtracks);

  syms x y

  % 1 point per step + initial step
  n_pts = n_steps + 1;

  % allocate space for outputs
  Xs = zeros(n_pts,2);
  fcn_vals = zeros(n_pts,1);

  % initialize X
  Xs(1,:) = init_X;

  for i=2:n_pts
    subbedx = subs(grad,x,Xs(i - 1,1));
    subbedy = double(subs(subbedx,y,Xs(i - 1,2)));

    % DIDN'T HAVE ENOUGH TIME TO FINISH DEBUGGING THIS...

    %%%Backtracking Line Search%%%
    t = 1;
    num_backtracks = 1;
    while(subs(fcn,[x y], Xs(i - 1,:) - t*stepsize*subbedy') > subs(fcn,[x y], Xs(i - 1,:)) - alpha*t*norm(subbedy))
      t = beta*t; % shorter step size
      f_there = double(subs(fcn, [x; y], Xs(:,i) + t.*d));
      num_backtracks = num_backtracks + 1;
      if(num_backtracks > max_backtracks) break; end
    end

    Xs(i,:) = Xs(i - 1,:) - t*stepsize*subbedy';
  end

  % calculate fcn_vals at each point in Xs
  for i=1:n_pts
    fcn_vals(i) = subs(fcn,[x y], Xs(i,:));
  end

  Xs = Xs';

end
