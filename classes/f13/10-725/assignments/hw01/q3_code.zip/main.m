set(0, 'defaultaxesfontsize', 20);
rng shuffle;
stepsize0_bt   = 1;
bt_rate        = .5;
nb_bt_steps    = 10;
slope_ratio    = .5;

syms x y

% objective functions
f{1} = 1.125.*x.^2 + 0.5.*x.*y + 0.75.*y.^2 + 2.*x + 2.*y;
f{2} = 0.5.*(x.^2 + y.^2) + 50.*log(1 + exp(-0.5.*y)) + 50.*log(1 + exp(0.2.*x));
f{3} = 0.1.*(x.^2 + y - 11).^2 + 0.1.*(x + y.^2 - 7).^2;
f{4} = 0.002.*(1 - x).^2 + 0.2.*(y - x.^2).^2;

% gradient functions
for i=1:4
  grad_f{i} = gradient(f{i});
end

%figure(1); clf;
%for i=1:4
%  subplot(2,2,i);
%  ezsurfc(f{i});
%
%  axis([-6 6 -6 6 -100 Inf]);
%  if(i == 4)
%    axis([-3 3 -6 6 -100 Inf]);
%  end
%  view(-80,40);
%end

% first 3 random starting points
rand_init = 12.*(rand(3,2) - 0.5);
% fourth random starting point
rand_init(4,:) = [6.*(rand(1) - 0.5) 12.*(rand(1) - 0.5)];
nb_steps = 1000;
step_sizes = [0.3 0.8];

for i=1:4
  figure(i + 5)
  clf
  for stepi = 1:2
    for init_Xi = 1:2
    step_size = step_sizes(stepi);
      if(init_Xi == 1) init_X = [2 3];
      else init_X = rand_init(i,:);
      end

      % gradient descent with fixed stepsize
      [Xs, fcn_vals] = gd_fixed_stepsize(f{i}, grad_f{i}, ...
        init_X, nb_steps, step_size);

      subplot(2,2,2.*(stepi - 1) + init_Xi);
      ezcontour(f{i});
      hold on;
      plot(Xs(1,:), Xs(2,:),'.-');

      axis([-6 6 -6 6]);
      if(i == 4)
        axis([-3 3 -6 6]);
      end

    end
  end
end

%
%% gradient descent with backtrack
%[Xs_bt, fcn_vals_bt, stepsizes_bt] = gd_backtrack( fcn, grad_fcn, ...
%  init_X, nb_steps, stepsize0_bt, bt_rate, nb_bt_steps, slope_ratio);
%
%figure(3); clf; ezcontour(@(x,y) x.^2+2*y.^2);
%hold on;   plot(Xs_bt(1,:), Xs_bt(2,:), '.-');
%
%% save
%saveas(1, 'a_shape.eps', 'psc2'); saveas(2, 'a_fix.eps', 'psc2');
%saveas(3, 'a_bt.eps', 'psc2');
