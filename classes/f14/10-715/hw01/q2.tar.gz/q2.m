% Matlab Script for HW1 q2

clear all;
close all;

data = 'data1.mat';
data = 'data2.mat';

load(data);

% Set hyper params
lambda = 0.1;
theta0 = 2 * ones(K, 1);

% Training
[theta, alpha] = trainPDA(XTrain, yTrain, theta0, lambda);

% Obtain predictions for Test data
preds = predictPDA(XTest, theta, alpha);

if strcmp(data, 'data1.mat')
  theta, alpha, preds,
else
  theta, alpha(:, 1:5), preds(1:5),
end

% Report the accuracy
acc = sum(yTest == preds) / size(yTest,1);
fprintf('Accuracy: %0.4f\n', acc);

